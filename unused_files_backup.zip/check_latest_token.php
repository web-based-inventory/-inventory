<?php
require 'config/database.php';

// Get the latest valid token from the database that hasn't expired
$stmt = $conn->prepare("SELECT id, user_id, expires_at FROM password_resets WHERE used_at IS NULL AND expires_at > NOW() ORDER BY id DESC LIMIT 1");
$stmt->execute();
$res = $stmt->get_result();
$record = $res->fetch_assoc();

if ($record) {
    echo "Found valid token record ID: " . $record['id'] . "\n";
} else {
    echo "No valid tokens found in the database.\n";
}
?>
