<?php
require 'config/database.php';
$token = bin2hex(random_bytes(32));
$token_hash = hash('sha256', $token);
echo "Token: $token\n";
echo "Hash: $token_hash\n";

// Insert
$stmt = $conn->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (1, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))");
$stmt->bind_param("s", $token_hash);
$stmt->execute();

// Select
$stmt = $conn->prepare("SELECT id, user_id, expires_at, NOW() as n FROM password_resets WHERE token_hash = ? AND used_at IS NULL AND expires_at > NOW() LIMIT 1");
$stmt->bind_param("s", $token_hash);
$stmt->execute();
$res = $stmt->get_result();
print_r($res->fetch_assoc());
?>
