<?php
require 'config/database.php';
$res = $conn->query('SELECT NOW() as n');
print_r($res->fetch_assoc());
echo " PHP Time: " . date('Y-m-d H:i:s');
?>
