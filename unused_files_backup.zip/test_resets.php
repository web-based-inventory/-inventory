<?php
require 'config/database.php';
$res = $conn->query('SELECT * FROM password_resets ORDER BY id DESC LIMIT 1');
if($res) {
    print_r($res->fetch_assoc());
} else {
    echo "Error: " . $conn->error;
}
?>
