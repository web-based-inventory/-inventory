<?php
$base_dir = __DIR__;
$exclude_dirs = ['.git', 'node_modules', 'vendor'];
$all_files = [];
$all_files_relative = [];

// 1. Get all files
$iterator = new RecursiveIteratorIterator(
    new RecursiveCallbackFilterIterator(
        new RecursiveDirectoryIterator($base_dir, RecursiveDirectoryIterator::SKIP_DOTS),
        function ($fileInfo, $key, $iterator) use ($exclude_dirs) {
            if ($fileInfo->isDir() && in_array($fileInfo->getFilename(), $exclude_dirs)) {
                return false;
            }
            return true;
        }
    )
);

foreach ($iterator as $file) {
    if ($file->isFile()) {
        $all_files[] = $file->getPathname();
        $all_files_relative[] = str_replace('\\', '/', str_replace($base_dir . DIRECTORY_SEPARATOR, '', $file->getPathname()));
    }
}

// 2. Scan content for references
$references = [];
foreach ($all_files as $file) {
    $content = file_get_contents($file);
    // Find things that look like file names with extensions .php, .css, .js, .png, .jpg, .svg, .html
    preg_match_all('/[\w\-\.\/\\\\]+\.(php|css|js|png|jpg|jpeg|svg|html|sql)\b/i', $content, $matches);
    foreach ($matches[0] as $match) {
        $basename = basename(str_replace('\\', '/', $match));
        $references[$basename] = true;
    }
}

// 3. Classify
$used = [];
$unused = [];
$uncertain = [];

$safe_to_keep_regex = '/(config|db|database|auth|permission|helpers|header|footer|sidebar|theme-init|modal|toast|migrate|check_tables|smart_inventory\.sql|tailwind\.config\.js|\.htaccess|\.gitignore)/i';

foreach ($all_files_relative as $rel_file) {
    $basename = basename($rel_file);
    $ext = pathinfo($basename, PATHINFO_EXTENSION);
    
    // Always keep SQL files
    if (strtolower($ext) === 'sql') {
        $used[] = $rel_file;
        continue;
    }

    // Always keep config and important files
    if (preg_match($safe_to_keep_regex, $basename) || strpos($rel_file, 'config/') === 0 || strpos($rel_file, 'lib/') === 0) {
        $used[] = $rel_file;
        continue;
    }

    if (isset($references[$basename])) {
        $used[] = $rel_file;
    } else {
        // If not explicitly referenced, is it an entry point?
        if ($basename === 'index.php' || $basename === 'login.php' || $basename === 'logout.php' || $basename === 'pos.php') {
            $used[] = $rel_file; // Entry points might only be accessed via URL
        } elseif (in_array(strtolower($ext), ['png', 'jpg', 'jpeg', 'svg', 'gif'])) {
            $uncertain[] = $rel_file; // Images could be dynamic
        } elseif (strpos($rel_file, 'uploads/') === 0 || strpos($rel_file, 'img/') === 0) {
            $uncertain[] = $rel_file; // Uploads are dynamic
        } else {
            // These might be unused
            $unused[] = $rel_file;
        }
    }
}

$report = [
    'used' => $used,
    'unused' => $unused,
    'uncertain' => $uncertain
];

file_put_contents('audit_report.json', json_encode($report, JSON_PRETTY_PRINT));
echo "Audit complete. Saved to audit_report.json\n";
?>
